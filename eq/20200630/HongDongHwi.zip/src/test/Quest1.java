package test;

public class Quest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 2; i <= 9; i++)
		{
			for (int j = 1; j <= 9; j++)
			{
				int result = i * j;
				System.out.println(i+"x"+j+"="+result);
			}
			System.out.println("");
		}
		
	}

}
